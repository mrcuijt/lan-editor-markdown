# HelloJUnit5

This repository accompanies Part 1 of my Junit 5 Tutorial series on [IBM developerWorks](https://ibm.co/2uWIwcp).

Publication date: July 2017
Update: December 2017

Uses JUnit 5, Version 5.0.2.

Cheers,
J Steven Perry

@jstevenperry
