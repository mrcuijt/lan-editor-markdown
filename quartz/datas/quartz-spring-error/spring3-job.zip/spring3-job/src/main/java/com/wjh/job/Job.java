package com.wjh.job;

import org.apache.log4j.Logger;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 *
 * @author wenjianhai
 * @date 2019年3月9日
 * @since JDK 1.8
 */
@Component
public class Job {

	private static final Logger logger = Logger.getLogger(Job.class);

	// 0/15 * * * * ?  15秒钟执行一次
	// 0 0/1 * * * ?  一分钟执行一次
	@Scheduled(cron = "0/15 * * * * ?")
	public void doSomething() {
		logger.info("doSomething");
	}
}
