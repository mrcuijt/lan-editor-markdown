module.exports = {
    cookieSecret:"blog",
    db:"blog",
    host:"localhost",
	port:27017
}