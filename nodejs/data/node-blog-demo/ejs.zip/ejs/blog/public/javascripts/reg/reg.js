var lis = $("ul.nav.navbar-nav li");
$(lis).removeClass();
$($(lis)[2]).addClass('active');