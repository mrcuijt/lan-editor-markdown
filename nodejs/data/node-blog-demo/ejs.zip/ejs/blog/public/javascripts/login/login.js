var lis = $("ul.nav.navbar-nav li");
$(lis).removeClass();
$($(lis)[1]).addClass('active');