var mongodb = require("./db"); // 引入数据库模块实例
var settings = require("../settings");
// 声明 User 类
function User(user){
  this.name=user.name;
  this.password=user.password;
}

/**
 * 增加查询用户静态方法
 * @param username 用户名
 * @param callback
 */
 User.find = function(username,callback){
   mongodb.connect('mongodb://'+settings.host+"/"+settings.db,function(err,db){
	   if(err){
		   return callback(err);
	   }
	   var dbo = db.db(settings.db);
	   dbo.collection("users").find({"name":username}).toArray(callback);
	   db.close();
   });
 }

// 将 User 类给予接口
module.exports = User;

/**
 * 使用原型增加保存方法
 * @param callback
 */
User.prototype.save=function(callback){
	// 存入 mongodb 的文档
	var user={
		name:this.name,
		password:this.password
	};
	mongodb.connect('mongodb://'+settings.host+"/"+settings.db,function(err,db){
		if(err){
			db.close();
			return callback(err);
		}
 		var dbo = db.db(settings.db);
		dbo.collection("users").insertOne(user,function(err,res){
			if(err){
				db.close();
				return callback(err);
			}
			callback(err,res)
		});
		// 为 name 属性增加索引
		// collection.ensureIndex("name",{unique:true});
		// 写入 User 文档
		// collection.insert(user,{safe:true},function(err){
		//	mongodb.close();
		//	return callback(err);
		// });
	});
}
