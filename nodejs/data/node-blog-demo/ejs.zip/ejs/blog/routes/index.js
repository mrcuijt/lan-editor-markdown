var crypto=require("crypto");
var User = require("../modules/User");
var express = require('express');
//var bodyParser = require('body-parser');
var router = express.Router();
var querystring = require('querystring');


//app.use(bodyParser.json());
//app.use(bodyParser.urlencoded({ extended: false }));

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});


// 用户登录
router.get('/login', function(req, res){

  res.render('login', { title: '用户登录', layout: 'layout' });
});

router.post('/doLogin', function(req, res){

	if(req.body["username"]) return res.redirect("/login");
	if(req.body["password"]) return res.redirect("/login");

	User.find(req.body["username"],function(err,user){
		if(err){
			req.session.error = err;
			return res.redirect("/login");
		}
		if(user.length < 0){
			req.session.error = "用户名或密码错误";
			return res.redirect("/login");
		}
		var md5 = crypto.createHash('md5');
		var password = md5.update(req.body.password).digest("base64");
		if(password != user[0].password){
			req.session.error = "用户名或密码错误";
			return res.redirect("/login");
		}
		req.session.success = "登录成功";
		req.session.user = user[0];
		return res.redirect('/user/'+user[0].user);
	});
});

// 用户退出
router.get('/logout', function(req, res){
  req.session.user = null;
  res.redirect('/');
});


// 用户的主页
router.get('/user/:user', function(req, res){
  res.render('user', {title: '用户', layout: 'layout' });
});


// 用户注册
router.get('/reg', function(req, res){
  res.render('reg', { title: '用户注册', layout: 'layout' });
});

router.post('/doReg', function(req, res){

  // 校验用户两次输入的口令是否一致
  if(req.body["password-repeat"]!=req.body["password"]){
	  req.session.error="两次输入口令不一致";
	  return res.redirect("/reg");
  }
  // 生成口令的散列值，我们使用 md5 加密
  var md5=crypto.createHash('md5');
  var password=md5.update(req.body.password).digest("base64");
  // 声明需要添加的用户
  var newUser=new User({
	  name:req.body.username,
	  password:password
  });

  User.find(newUser.name,function(err,user){
	  console.log(user);
	  // 如果用户已经存在
	  if(user.length > 0){
		  req.session.error="该用户已经存在";
		  return res.redirect("/reg");
	  }
	  //如果用户不存在则添加用户
	  newUser.save(function(err){
		  if(err){
			  req.sessioin.error=err;
			  return res.redirect("/reg");
		  }
		  req.session.user=newUser;
		  req.session.success="注册成功";
		  res.locals.user=newUser;
		  res.redirect("/");
	  });
  });
});


module.exports = router;
