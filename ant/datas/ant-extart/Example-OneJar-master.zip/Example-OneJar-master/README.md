# OneJar-Example
Demonstration of Ant &amp; OneJar "Hello world" application

