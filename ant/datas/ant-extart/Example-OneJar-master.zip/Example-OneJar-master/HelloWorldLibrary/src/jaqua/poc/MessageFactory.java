package jaqua.poc;

public interface MessageFactory {
    public String createMessage();
}
