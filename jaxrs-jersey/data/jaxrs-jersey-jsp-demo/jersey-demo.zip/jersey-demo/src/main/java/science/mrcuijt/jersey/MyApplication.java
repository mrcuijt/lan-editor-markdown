package science.mrcuijt.jersey;

import org.glassfish.jersey.logging.LoggingFeature;
import org.glassfish.jersey.server.ResourceConfig;
import org.glassfish.jersey.server.ServerProperties;
import org.glassfish.jersey.server.TracingConfig;
import org.glassfish.jersey.server.mvc.jsp.JspMvcFeature;

/**
 * @author Administrator
 */
public class MyApplication extends ResourceConfig {

	public MyApplication() {

		// Resources.
		packages("science.mrcuijt.jersey.resource");

		// MVC.
		register(JspMvcFeature.class);

		// Logging.
		register(LoggingFeature.class);

		// Tracing support.
		property(ServerProperties.TRACING, TracingConfig.ON_DEMAND.name());
	}
}
