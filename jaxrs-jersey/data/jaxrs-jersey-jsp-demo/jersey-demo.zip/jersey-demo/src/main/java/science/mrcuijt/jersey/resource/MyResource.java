/**
 * 
 */
package science.mrcuijt.jersey.resource;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import org.glassfish.jersey.server.mvc.Viewable;

/**
 * @author Administrator
 *
 */
@Path("/")
public class MyResource {

	@GET
	@Path("viewable/{username}/")
	@Produces(MediaType.TEXT_HTML)
	public Viewable getViewable(@PathParam("username") String username, @Context HttpServletRequest request) {
		String message = "Hello";
		request.setAttribute("message", message);
		request.setAttribute("username", username);
		return new Viewable("/viewable.jsp");
	}

}